package edu.adamumkc.leilashairmuseumhistory.JSON;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Adam on 3/15/2016.
 */
public class museumdatabase {
    String filename = "Hair Museum Database";
    String address = "http://leilashairmuseum.net/files/Android/Hair%20Museum%20Database.xlsx";

    private static final String TAG = museumdatabase.class.getName();

    public static JSONObject getmuseumdatabaseObject(String address) throws JSONException {
        return new JSONObject(getmuseumdatabaseString(address));
    }

    public static String getmuseumdatabaseString(String address) {

        StringBuilder builder = new StringBuilder();
        try {

            URL url = new URL(address);
            HttpURLConnection connect = (HttpURLConnection) url.openConnection();
            connect.setReadTimeout(10000);
            connect.setConnectTimeout(12000);
            connect.setRequestMethod("GET");
            connect.setDoInput(true);
            connect.connect();
            int response = connect.getResponseCode();

            if (response == 200) {
                InputStream content = connect.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(content));
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
            } else {
                Log.e(TAG, "File download failed!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return builder.toString();
    }
    }
