package edu.adamumkc.leilashairmuseumhistory;

import android.test.AndroidTestCase;

public class AppTestCases extends AndroidTestCase{

    private about_leila about;
    private museum_info info;
    private search search;
    private model model;

    public void setup (  ) {
        about = new about_leila();
        info = new museum_info();
        search = new search();
        model = new model();
    }

    public void teardown (  ) {
        about = null;
        info = null;
        search = null;
        model = null;
    }

    public boolean pagesWork() {
        return true;
    }
}
