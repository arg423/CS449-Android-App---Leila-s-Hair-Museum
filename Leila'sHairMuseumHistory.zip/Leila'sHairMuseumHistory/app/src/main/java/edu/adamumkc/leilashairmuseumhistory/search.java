package edu.adamumkc.leilashairmuseumhistory;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import junit.framework.Assert;

public class search extends AppCompatActivity {
    EditText NUMBER_DISPLAY;
    String display;
    Button enter;
    Context ctxt = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        NUMBER_DISPLAY = (EditText) findViewById(R.id.number_display);
        enter = (Button) findViewById(R.id.numberpad_enter);
        enter.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                display = NUMBER_DISPLAY.getText().toString();
                int tempdisplay;
                try{
                    tempdisplay = Integer.parseInt(display);
                }catch(NumberFormatException e){            //if nothing is entered it sets the value to -1
                    tempdisplay = -1;
                }

/*
                if (display.isEmpty()) {
                    Toast.makeText(getBaseContext(), "Do not leave empty", Toast.LENGTH_LONG).show();
                    NUMBER_DISPLAY.setText("");
                }
*/
                if (tempdisplay == -1) {
                    Toast.makeText(getBaseContext(), "Do not leave empty", Toast.LENGTH_LONG).show();
                    NUMBER_DISPLAY.setText("");
                }
                else if (tempdisplay < 1 || tempdisplay > 5) {
                    Toast.makeText(getBaseContext(), "Must contain 1-5 only", Toast.LENGTH_LONG).show();
                    NUMBER_DISPLAY.setText("");
                }
                else {
                    try {
                        DatabaseProcesses db = new DatabaseProcesses(ctxt);
                        db.getReadableDatabase();
                        finish();
                    } catch (Exception e) {
                    }//This code does not do anything yet
                }
            }
        });
    }
}