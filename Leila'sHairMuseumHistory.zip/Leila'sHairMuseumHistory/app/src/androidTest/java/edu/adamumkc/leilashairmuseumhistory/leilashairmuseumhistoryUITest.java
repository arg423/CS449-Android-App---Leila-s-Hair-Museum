package edu.adamumkc.leilashairmuseumhistory;

import android.test.ActivityInstrumentationTestCase2;
import android.test.TouchUtils;
import android.widget.Button;
import android.widget.TextView;

class leilashairmuseumhistoryUITest extends ActivityInstrumentationTestCase2<MainActivity> {

    private MainActivity activity;
    public leilashairmuseumhistoryUITest() {
        super(MainActivity.class);
    }


    public void setUp(  )  {
        // setActivityInitialTouchMode(false) allows to send key events via test.
        setActivityInitialTouchMode(false);
        activity = (MainActivity) getActivity();
    }

    public void testPagesWork() throws Exception {

        Button search_button;
        search_button = (Button) activity.findViewById(R.id.search_button);
        assertNotNull(search_button);

        Button museum_info_button;
        museum_info_button = (Button) activity.findViewById(R.id.museum_info_button);
        assertNotNull(museum_info_button);

        Button about_leila_button;
        about_leila_button = (Button) activity.findViewById(R.id.about_leila_button);
        assertNotNull(about_leila_button);

        assertEquals("Doesn't go to page",false,true);
        // TouchUtils handles the sync with the main thread internally
        TouchUtils.clickView(this, search_button);

        assertEquals("Doesn't go to page",false,true);
        // TouchUtils handles the sync with the main thread internally
        TouchUtils.clickView(this, museum_info_button);

        assertEquals("Doesn't go to page", false,true);
        // TouchUtils handles the sync with the main thread internally
        TouchUtils.clickView(this, about_leila_button);

        // I think you have to do this after sending input to UI
        getInstrumentation().waitForIdleSync();

    }
}
