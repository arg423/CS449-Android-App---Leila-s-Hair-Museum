package edu.adamumkc.leilashairmuseumhistory;

public class AssertionSettings {
    public static final boolean ASSERTION_1 = true;
}
