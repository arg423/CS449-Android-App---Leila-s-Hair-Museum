package edu.adamumkc.leilashairmuseumhistory;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * http://d.android.com/tools/testing/testing_android.html
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }

    // do test cases for going to pages since that is all that works

}