package edu.adamumkc.leilashairmuseumhistory.JSON;

/**
 * Created by Adam on 3/15/2016.
 */
public class data {
    private int itemNumber;
    private String pictureNumber;
    private String itemDescription;

   public data(int itemNumber, String pictureNumber, String itemDescription) {

        this.itemNumber = itemNumber;
        this.pictureNumber = pictureNumber;
        this.itemDescription = itemDescription;
    }

    public String toString(){
        return itemNumber + '\n' + pictureNumber + '\n' + itemDescription;
    }








}
