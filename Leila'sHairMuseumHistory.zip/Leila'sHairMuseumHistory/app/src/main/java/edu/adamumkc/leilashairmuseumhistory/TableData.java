package edu.adamumkc.leilashairmuseumhistory;

import android.provider.BaseColumns;

public class TableData {

    public TableData(){

    }

    public static abstract class TableInfo implements BaseColumns{
        public static final String DATABASE_NAME = "hair_museum_database";
        public static final String TABLE_NAME = "item_info";
        public static final String ITEM_NUMBER = "item_number";
        public static final String PICTURE_NUMBER = "picture_number";
        public static final String ITEM_DESCRIPTION = "item_description";
    }
}
