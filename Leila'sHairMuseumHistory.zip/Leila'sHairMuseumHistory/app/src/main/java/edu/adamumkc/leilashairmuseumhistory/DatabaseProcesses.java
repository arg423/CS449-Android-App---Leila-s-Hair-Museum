package edu.adamumkc.leilashairmuseumhistory;


import android.content.ContentValues;
import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import junit.framework.Assert;

import edu.adamumkc.leilashairmuseumhistory.TableData.TableInfo;

public class DatabaseProcesses extends SQLiteOpenHelper{
    public static final int database_version = 1;
    public String CREATE_QUERY = "CREATE TABLE" + TableInfo.TABLE_NAME + "( " + TableInfo.ITEM_NUMBER + " TEXT, " + TableInfo.PICTURE_NUMBER + " TEXT, " + TableInfo.ITEM_DESCRIPTION + " TEXT);";

    public DatabaseProcesses(Context context) {
        super(context, TableInfo.DATABASE_NAME, null, database_version);
        Log.d("Database Processes", "Database Created");
    }

    public DatabaseProcesses(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QUERY);
        Log.d("Database Processes", "Database Created");

       // Assertion for database if it is null
        if (AssertionSettings.ASSERTION_1){
            Assert.assertNull("This should not be null", db);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addTableInfo(DatabaseProcesses dataproc, String item, String picture, String description){
        SQLiteDatabase SQLDB = dataproc.getWritableDatabase();
        ContentValues ConVal = new ContentValues();
        ConVal.put(TableInfo.ITEM_NUMBER, item);
        ConVal.put(TableInfo.PICTURE_NUMBER, picture);
        ConVal.put(TableInfo.ITEM_DESCRIPTION, description);
        long row = SQLDB.insert(TableInfo.TABLE_NAME, null, ConVal);
        Log.d("Database Processes", "One row inserted");
    }
}
